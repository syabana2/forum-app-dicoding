import React from 'react';

function TopBar() {
  return (
    <div className='top-bar'>
      <h1>Dicoding Forum App</h1>
    </div>
  );
};

export default TopBar;
